public class Go

{
      public static void main(String [] args)

      {

           Login f1 = new Login();

           f1.show();

           //f1.setVisible(true);

      }
}